﻿using System;
using System.Collections.Generic;
using Commum;
using System.Text;

namespace Drive
{
    class Program
    {
        static void Main(string[] args)
        {

            Service.ElevadorService svc = new Service.ElevadorService();

            Console.Clear();

            mostrarCabecalho();

            mostrarAndarMenosUtilizados(svc.andarMenosUtilizado());

            mostrarElevadoresMaisFrequentados(svc.elevadorMaisFrequentado());
            
            mostrarElevadoresMenosFrequentados(svc.elevadorMenosFrequentado());
            
            mostrarPercentualUso('A',svc.percentualDeUsoElevadorA(), 'd');
            
            mostrarPercentualUso('B',svc.percentualDeUsoElevadorB(), 'e');
            
            mostrarPercentualUso('C',svc.percentualDeUsoElevadorC(), 'f');
            
            mostrarPercentualUso('D',svc.percentualDeUsoElevadorD(), 'g');
            
            mostrarPercentualUso('E',svc.percentualDeUsoElevadorE(), 'h');
            
            mostrarMaiorFluxoElevadorMaisFrequentado(svc.periodoMaiorFluxoElevadorMaisFrequentado());
            
            mostrarMaiorUtilizacaConjuntoElevadores(svc.periodoMaiorUtilizacaoConjuntoElevadores());
            
            mostrarMenorFluxoElevadorMenosfrequentado(svc.periodoMenorFluxoElevadorMenosFrequentado());
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("***************************************************************************************");

            //Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("Obrigado pela oportunidade!");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("Digite uma tecla para sair . . .");
            Console.ReadKey();

        }

        private static void mostrarCabecalho(){
            Console.WriteLine("***************************************************************************************");
            Console.WriteLine("DESAFIO APISUL - 05/07/2021.");
            Console.WriteLine("Candidato: Rogério Tamizari.");
            Console.WriteLine("Liguagem: C#.");
            Console.WriteLine("IDE: Visual Studio Code.");
            Console.WriteLine("Fromt-End: Console Aplication.");
            Console.WriteLine("Plataforma: Microsoft.AspNetCore (SDK 5.0.301).");
            Console.WriteLine("***************************************************************************************");
            Console.WriteLine("");
        }
        private static void mostrarAndarMenosUtilizados(List<int> menosUtilizados){
            // Print Console elevador(es) mais frequentado(s)
            StringBuilder msg = new StringBuilder();
            msg.Append("\na) Andar(es) menos utilizado(s): [");
            foreach (var item in menosUtilizados){
                
                msg.Append( " " + item.ToString() + ",");
            }
            msg.Remove(msg.Length-1, 1);
            msg.Append(" ] \n");
            Console.Write(msg.ToString());
        }
        private static void mostrarElevadoresMaisFrequentados(List<char> maisFrequentados){
            // Print Console
            StringBuilder msg = new StringBuilder();
            msg.Append("\nb) Elevador(es) mais frequentado(s): [");
            foreach (var item in maisFrequentados){
                
                msg.Append( " " + item.ToString() + ",");
            }
            msg.Remove(msg.Length-1, 1);
            msg.Append(" ] \n");
            Console.Write(msg.ToString());
        }

        private static void mostrarElevadoresMenosFrequentados(List<char> menosFrequentados){
                        // Print Console
            StringBuilder msg = new StringBuilder();
            msg.Append("\nc) Elevador(es) menos frequentado(s): [");
            foreach (var item in menosFrequentados){
                
                msg.Append( " " + item.ToString() + ",");
            }
            msg.Remove(msg.Length-1, 1);
            msg.Append(" ] \n");
            Console.Write(msg.ToString());
        }

        private static void mostrarPercentualUso(char elevador, float percentual, char idx){
            // Print Console
            StringBuilder msg = new StringBuilder();
            msg.Append("\n" + idx + ") Percentual de uso do elevador [" + elevador + "] Percentual: " + percentual.ToString("0.00") + "%; \n" );
            Console.Write(msg.ToString());
        }

        private static void mostrarMaiorFluxoElevadorMaisFrequentado(List<char> pMaioFlux){
            // Print Console
            StringBuilder msg = new StringBuilder();
            msg.Append("\ni) Periodo de maior fluxo do(s) elevador(es) mais frequentado(s): [");
            
            foreach (var item in pMaioFlux){    
                msg.Append( " " + item.ToString() + ",");
            }
            msg.Remove(msg.Length-1, 1);
            msg.Append(" ] \n");
            Console.Write(msg.ToString());
        }

        private static void mostrarMaiorUtilizacaConjuntoElevadores(List<char> pMaioFlux){
                         // Print Console
            StringBuilder msg = new StringBuilder();
            msg.Append("\nj) periodo(s) de maior utilização do conjunto de elevadores: [");
            foreach (var item in pMaioFlux){
                
                msg.Append( " " + item.ToString() + ",");
            }
            msg.Remove(msg.Length-1, 1);
            msg.Append(" ] \n");
            Console.Write(msg.ToString());
        }

        public static void mostrarMenorFluxoElevadorMenosfrequentado(List<char> pMenorFlux){
            // Print Console
            StringBuilder msg = new StringBuilder();
            msg.Append("\nk) Período de menor fluxo de cada um dos elevadores menos frequentados: [");
            foreach (var item in pMenorFlux){
                
                msg.Append( " " + item.ToString() + ",");
            }
            msg.Remove(msg.Length-1, 1);
            msg.Append(" ] \n");
            Console.Write(msg.ToString());
        }
    }
}
