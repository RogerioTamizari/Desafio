using System.Collections.Generic;
using System.IO;
using System.Text;
using Commum;
using System.Runtime.Serialization.Json;
using System;

namespace Data
{
    public class DadosEntrada{

        private static string caminhoArquivo =  AppDomain.CurrentDomain.DynamicDirectory +  @"..\Data\input.json";
        public List<Entrada> getDadosEntrada(){
            List<Entrada> entradas;
            try
            {
                var json = File.ReadAllText(caminhoArquivo);
                var js = new DataContractJsonSerializer(typeof(List<Entrada>));
                var ms = new MemoryStream(Encoding.UTF8.GetBytes(json));
                entradas = (List<Entrada>) js.ReadObject(ms);
            }
            catch (Exception)
            {
                entradas = new List<Entrada>();
                throw;
            }
            return entradas;
        }
             
    }
}