using System;
using System.Collections.Generic;
using Commum;
using System.Linq;
using System.Text;

namespace Service
{
    public class ElevadorService : IElevadorService
    {
        private static List<char> _elevadores = new List<char>{'A', 'B', 'C', 'D', 'E'};
        private static List<char> _turnos = new List<char>{'M', 'V', 'N'};
        private static int _numeroDeAndares = 16;

        #region "Publico"
        
        /// <summary> Deve retornar uma List contendo o(s) andar(es) menos utilizado(s). </summary>        
        public List<int> andarMenosUtilizado()
        {
            List<Entrada> entradas = buscarDados();
            List<Entrada> naoUtilizados = new List<Entrada>();
            List<int> menosUtilizados = new List<int>();

           //Considerando 16 andares, verificar se algun andar não foi citado no levantamento,
           //pois, neste caso, este deverá ser incluído na lista de menos utilizados.
           //O requisito não especifica se deve-se considerar apenas os que aparecem no arquivo.
           // TO DO: validar regra com o Cliente.

           int ocorrencias;
           for(int i = 0; i < _numeroDeAndares; i++){
                ocorrencias = (from e in entradas where e.andar == i select e).Count(); 
                if (ocorrencias == 0){
                    Entrada e = new Entrada();
                    e.andar = i;
                    naoUtilizados.Add (e);
                }
            }

            if (naoUtilizados.Count > 0){
                menosUtilizados = (from na in naoUtilizados select na.andar).ToList<int>();
            }else{
                var freq = from e in entradas group e by e.andar into g
                            select new { 
                                andar = g.Key, oc = g.Count(), 
                            };
                int vlrmax =  freq.Min(x => x.oc);
                menosUtilizados = (from mu in freq where mu.oc == vlrmax select mu.andar).ToList<int>();
            }

            return menosUtilizados;

        }

        /// <summary> Deve retornar uma List contendo o(s) elevador(es) mais frequentado(s). </summary>
        public List<char> elevadorMaisFrequentado()
        {
            List<char> maisFrequentados;
            List<Entrada> entradas = buscarDados();

            var freq = from e in entradas where _elevadores.Contains(e.elevador) group e by e.elevador into grp
                            select new { 
                                elevador = grp.Key, oc = grp.Count(), 
                            };

            int vlrmax =  freq.Max(x => x.oc);
                maisFrequentados = (from mu in freq where mu.oc == vlrmax select mu.elevador).ToList<char>();

            return maisFrequentados;
        }

        /// <summary> Deve retornar uma List contendo o(s) elevador(es) menos frequentado(s). </summary>
        public List<char> elevadorMenosFrequentado()
        {
            
            List<char> menosFrequentados;
            List<Entrada> entradas = buscarDados();

            var freq = from e in entradas where _elevadores.Contains(e.elevador) group e by e.elevador into grp
                            select new { 
                                elevador = grp.Key, oc = grp.Count(), 
                            };

            int vlrmin =  freq.Min(x => x.oc);
            menosFrequentados = (from mu in freq where mu.oc == vlrmin select mu.elevador).ToList<char>();
            
            return menosFrequentados;
        }

        /// <summary> Deve retornar um float (duas casas decimais) contendo o percentual de uso do elevador A em relação a todos os serviços prestados. </summary>
        public float percentualDeUsoElevadorA()
        {
            return percentualDeUsoElevador('A');
        }

        /// <summary> Deve retornar um float (duas casas decimais) contendo o percentual de uso do elevador B em relação a todos os serviços prestados. </summary>
        public float percentualDeUsoElevadorB()
        {
            return percentualDeUsoElevador('B');
        }

        /// <summary> Deve retornar um float (duas casas decimais) contendo o percentual de uso do elevador C em relação a todos os serviços prestados. </summary>
        public float percentualDeUsoElevadorC()
        {
            return percentualDeUsoElevador('C');
        }

        /// <summary> Deve retornar um float (duas casas decimais) contendo o percentual de uso do elevador D em relação a todos os serviços prestados. </summary>
        public float percentualDeUsoElevadorD()
        {
            return percentualDeUsoElevador('D');;
        }

        /// <summary> Deve retornar um float (duas casas decimais) contendo o percentual de uso do elevador E em relação a todos os serviços prestados. </summary>
        public float percentualDeUsoElevadorE()
        {
            return percentualDeUsoElevador('E');
        }

        /// <summary> Deve retornar uma List contendo o período de maior fluxo de cada um dos elevadores mais frequentados (se houver mais de um). </summary>
        public List<char> periodoMaiorFluxoElevadorMaisFrequentado()
        {
            List<char> pMaioFlux = new List<char>();
            List<char> elvMaisFreq = this.elevadorMaisFrequentado();
            List<Entrada> entradas = buscarDados();

            var freq = from e in entradas where elvMaisFreq.Contains(e.elevador) group e by e.turno into grp
                            select new { 
                                turno = grp.Key, oc = grp.Count(), 
                            };
            int vlrmax =  freq.Max(x => x.oc);
            pMaioFlux = (from mu in freq where mu.oc == vlrmax select mu.turno).ToList<char>();

           return pMaioFlux;
        }

        /// <summary> Deve retornar uma List contendo o(s) periodo(s) de maior utilização do conjunto de elevadores. </summary>
        public List<char> periodoMaiorUtilizacaoConjuntoElevadores()
        {
            List<char> pMaioFlux = new List<char>();
            List<Entrada> entradas = buscarDados();
            
            var freq = from e in entradas where _elevadores.Contains(e.elevador) group e by e.turno into grp
                            select new { 
                                turno = grp.Key, oc = grp.Count(), 
                            };
            int vlrmax =  freq.Max(x => x.oc);
            pMaioFlux = (from mu in freq where mu.oc == vlrmax select mu.turno).ToList<char>();

           return pMaioFlux;
        }

        /// <summary> Deve retornar uma List contendo o período de menor fluxo de cada um dos elevadores menos frequentados (se houver mais de um). </summary>
        public List<char> periodoMenorFluxoElevadorMenosFrequentado()
        {
                        List<char> prdMenosFreq = new List<char>();
            List<char> elvMenosFreq = this.elevadorMenosFrequentado();
            List<Entrada> entradas = buscarDados();
            List<char> naoUtilizados = new List<char>();

            for(int i = 0; i < elvMenosFreq.Count; i++){
                for(int j = 0; j < _turnos.Count(); j++){
                    var nflux = (from e in entradas where elvMenosFreq[i] == e.elevador && _turnos[j] == e.turno group e by e.turno into grp
                    select new { 
                                turno = grp.Key, oc = grp.Count(), 
                            }).FirstOrDefault();

                    if(nflux == null){
                        naoUtilizados.Add(_turnos[j]);
                    }else{
                        var flux = (from e in entradas where elvMenosFreq[i] == e.elevador && _turnos[j] == e.turno group e by e.turno into grp
                        select new { 
                                turno = grp.Key, oc = grp.Count(), 
                            }).ToList();

                        int vlrmin =  flux.Min(x => x.oc);
                        prdMenosFreq.AddRange((from mu in flux where mu.oc == vlrmin select mu.turno).ToList());

                    }
                }
            }
            List<char> result;
            if(naoUtilizados.Count > 0){
                result = naoUtilizados;
            }else{
                result = prdMenosFreq;
            }

            return result;
        }

        #endregion
    
        #region "Privado"
        public List<Entrada> buscarDados(){
            List<Entrada> entradas;
            Data.DadosEntrada dados = new Data.DadosEntrada();
            entradas = dados.getDadosEntrada();
            return entradas;
        }

        private float percentualDeUsoElevador(char elevador){
            List<Entrada> entradas = buscarDados();

            float percentual;

            int totalUso = entradas.Count();

            var freq = (from e in entradas where e.elevador == elevador select e).ToList();

            percentual =  (float) (100 * freq.Count() ) / totalUso;

            return percentual;
        }
        #endregion
    }
}