﻿using System;

namespace Commum
{
    public class Class1
    {
    }
}
