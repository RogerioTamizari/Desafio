using System;

namespace Commum
{
    public class Entrada
    {
        private int _andar;
        private char _elevador;
        private char _turno;

        public int andar { get => _andar; set => _andar = value; }
        public char elevador { get => _elevador; set => _elevador = value; }
        public char turno { get => _turno; set => _turno = value; }
        
    }
}